import time
import random
inputList = list(range(5000))
random.shuffle(inputList)


def bubbleSort(inputList):
    inputList = list(inputList)
    if inputList is None or len(inputList) == 1:
        return inputList
    for i in range(len(inputList) -1):
        for i in range(len(inputList)  - 1):
            if inputList[i] > inputList[i+1]:   
                inputList[i], inputList[i+1] = inputList[i+1], inputList[i]
    return inputList
startTime = time.time()
output = (bubbleSort(inputList))
endTime = time.time()

timeUsed = endTime - startTime
print("Executred in (Bubble Approach)", timeUsed)
