import time
import random

#Change the value to increase the number of operations (Complexity)
value = 10000

def sortInsert(inputList):
    for i in range(len(inputList)):
        currentNum = inputList.pop(i)
        j = i - 1
        while j > 0 and inputList[j] > currentNum:
            j -= 1
        inputList.insert(j+1, currentNum)
    return inputList

def bubbleSort(inputList):
    inputList = list(inputList)
    if inputList is None or len(inputList) == 1:
        return inputList
    for i in range(len(inputList) -1):
        for i in range(len(inputList)  - 1):
            if inputList[i] > inputList[i+1]:   
                inputList[i], inputList[i+1] = inputList[i+1], inputList[i]
    return inputList


def brutalSort(unsortedList):
    outputList = []
    if unsortedList is None or len(unsortedList) == 1:
        return unsortedList
    while True:
        if len(unsortedList) < 1:
            return outputList
        maximum = min(unsortedList)
        indexOfMax = unsortedList.index(maximum)
        outputList.append(maximum)
        unsortedList.pop(indexOfMax)

def mergeSort(inputList):
    if len(inputList) <=1:
        return inputList
    mid = len(inputList) // 2
    firstHalf = inputList[:mid]
    secondHalf = inputList[mid:]
    
    leftSorted, rightSorted = mergeSort(firstHalf), mergeSort(secondHalf)
    
    sortedList = merge(leftSorted, rightSorted)
    
    return sortedList
    
def merge(list01, list02):
    merged = []
    i, j = 0,0
    
    while i < len(list01) and j < len(list02):
        if list01[i] <= list02[j]:
            merged.append(list01[i])
            i += 1
        else:
            merged.append(list02[j])
            j += 1
            
    return merged + list01[i:] + list02[j:]
        
def quickSort(inputList):
    left = []
    right = []
    if len(inputList) <= 1:
        return inputList
    pivot = inputList.pop(-1)
    for i in inputList:
        if pivot < i:
            right.append(i)
        else:
            left.append(i)
    leftSorted, rightSorted = quickSort(left), quickSort(right)
    outputList = leftSorted + [pivot] + rightSorted
    return (outputList)
        

outputList = list(range(value))
inputList = list(outputList)
random.shuffle(inputList)
print("\n\n---------------------- Insert Approach ----------------------")
startTime = time.time()
output = (sortInsert(inputList))
endTime = time.time()
timeUsed = endTime - startTime
print("Executed in (Insert Approach): ", timeUsed)
print("-------------------------------------------------------------")



outputList = list(range(value))
inputList = list(outputList)
random.shuffle(inputList)
print("\n\n---------------------- Bubble Approach ----------------------")
startTime = time.time()
output = (bubbleSort(inputList))
endTime = time.time()
timeUsed = endTime - startTime
print("Executed in (Bubble Approach): ", timeUsed)
print("-------------------------------------------------------------")


outputList = list(range(value))
inputList = list(outputList)
random.shuffle(inputList)
print("\n\n---------------------- Brutal Approach ----------------------")
startTime = time.time()
output = (sortInsert(inputList))
endTime = time.time()
timeUsed = endTime - startTime
print("Executed in (Brutal Approach): ", timeUsed)
print("-------------------------------------------------------------")

outputList = list(range(value))
inputList = list(outputList)
random.shuffle(inputList)
print("\n\n---------------------- Merged Approach ----------------------")
startTime = time.time()
output = (mergeSort(inputList))
endTime = time.time()
timeUsed = endTime - startTime
print("Executed in (Merged Approach): ", timeUsed)
print("-------------------------------------------------------------")

outputList = list(range(value))
inputList = list(outputList)
random.shuffle(inputList)
print("\n\n--------------------- Quick Sort Approach ---------------------")
startTime = time.time()
output = (quickSort(inputList))
endTime = time.time()
timeUsed = endTime - startTime
print("Executed in (Quick Sort Approach): ", timeUsed)
print("-------------------------------------------------------------")

