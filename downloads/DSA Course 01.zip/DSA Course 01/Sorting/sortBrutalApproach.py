import time
import random 
inputList = list(range(5000))
random.shuffle(inputList)


def brutalSort(unsortedList):
    outputList = []
    if unsortedList is None or len(unsortedList) == 1:
        return unsortedList
    while True:
        if len(unsortedList) < 1:
            return outputList
        maximum = min(unsortedList)
        indexOfMax = unsortedList.index(maximum)
        outputList.append(maximum)
        unsortedList.pop(indexOfMax)
        
startTime = time.time()
output = (brutalSort(inputList))
endTime = time.time()

timeUsed = endTime - startTime
print("Executred in (Brutal Approach)", timeUsed)

    