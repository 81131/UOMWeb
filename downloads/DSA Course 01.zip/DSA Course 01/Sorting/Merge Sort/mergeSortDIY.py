import time
import random 
inputList = list(range(10000000))
random.shuffle(inputList)

def mergeSort(inputList):
    if len(inputList) <=1:
        return inputList
    mid = len(inputList) // 2
    firstHalf = inputList[:mid]
    secondHalf = inputList[mid:]
    leftSorted, rightSorted = mergeSort(firstHalf), mergeSort(secondHalf)
    sortedList = merge(leftSorted, rightSorted)
    return sortedList
    
def merge(list01, list02):
    merged = []
    i, j = 0,0
    
    while i < len(list01) and j < len(list02):
        if list01[i] <= list02[j]:
            merged.append(list01[i])
            i += 1
        else:
            merged.append(list02[j])
            j += 1
            
    return merged + list01[i:] + list02[j:]
            
startTime = time.time()
output = (mergeSort(inputList))
endTime = time.time()

timeUsed = endTime - startTime
print("Executed in (Merged Approach)", timeUsed)
