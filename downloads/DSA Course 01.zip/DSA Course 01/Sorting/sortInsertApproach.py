import time
import random

outputList = list(range(5000))
inputList = list(outputList)
random.shuffle(inputList)

def sortInsert(inputList):
    for i in range(len(inputList)):
        currentNum = inputList.pop(i)
        j = i - 1
        while j > 0 and inputList[j] > currentNum:
            j -= 1
        inputList.insert(j+1, currentNum)
    return inputList

startTime = time.time()
output = (sortInsert(inputList))
endTime = time.time()


timeUsed = endTime - startTime
print("Executred in (Insert Approach)", timeUsed)

