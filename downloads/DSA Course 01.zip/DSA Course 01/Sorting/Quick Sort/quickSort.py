import time
import random

outputList = list(range(10000000))
inputList = list(outputList)
random.shuffle(inputList)

def quickSort(inputList):
    left = []
    right = []
    if len(inputList) <= 1:
        return inputList
    pivot = inputList.pop(-1)
    for i in inputList:
        if pivot < i:
            right.append(i)
        else:
            left.append(i)
    leftSorted, rightSorted = quickSort(left), quickSort(right)
    outputList = leftSorted + [pivot] + rightSorted
    return (outputList)

startTime = time.time()
output = (quickSort(inputList))
endTime = time.time()

timeUsed = endTime - startTime
print("Executed in (Quick Sort Approach)", timeUsed)