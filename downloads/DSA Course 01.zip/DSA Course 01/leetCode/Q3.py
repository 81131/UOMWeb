s = " "

# def lenOfLongestString(s):
#     lenList = []
#     for y in range(len(s)):
#         currentArrayList = ""
#         for i in s[y:]:
#             if i in currentArrayList:
#                 lenList.append(len(currentArrayList))
#                 break
#             else:
#                 if i == " ":
#                     currentArrayList += "i"
#                 currentArrayList += i
    
#     if len(lenList) != 0:
#         return max(lenList)
#     else:
#         return 0


def lenOfLongestString(s):
    lenList = []
    for y in range(len(s)):
        currentArrayList = ""
        for i in s[y:]:
            if i in currentArrayList:
                lenList.append(len(currentArrayList))
                break
            else:
                currentArrayList += i
        else:
            lenList.append(len(currentArrayList))
    
    if len(lenList) != 0:
        return max(lenList)
    else:
        return 0

# Test case
s = " "
print(lenOfLongestString(s))