# Definition for singly-linked list.
class ListNode(object):
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

class Solution(object):
    def addTwoNumbers(self, l1, l2):
        """
        :type l1: Optional[ListNode]
        :type l2: Optional[ListNode]
        :rtype: Optional[ListNode]
        """
        def iter(l):
            outNum = []
            current = l
            while current:
                outNum.append(current.val)
                current = current.next
            return outNum

        def appendOperation(head, data):
            current = head
            while current.next:  
                current = current.next
            current.next = ListNode(data)

        list01 = iter(l1)
        list02 = iter(l2)

        firstNum = int("".join(map(str, list01[::-1])))
        secondNum = int("".join(map(str, list02[::-1])))

        total = str(firstNum + secondNum)
        outList = [int(digit) for digit in total[::-1]]

        head = ListNode(outList[0])
        for digit in outList[1:]:
            appendOperation(head, digit)

        return head
