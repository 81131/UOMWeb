class HashTable:
    def __init__(self, maxSize):
        self.dataList = [None] * maxSize
    
    def getValidIndex(self, key):
        index = hash(key) % len(self.dataList)
        while True:
            keyValuePair = self.dataList[index]
            if keyValuePair is None:
                return index
            k, v = keyValuePair
            if k == key:
                return index
            index += 1    
            if index == len(self.dataList):
                index = 0
    
    def __getitem__(self, key):
        index = self.getValidIndex(key)
        keyValuePair = self.dataList[index]
        if keyValuePair is None:
            raise KeyError(f"Key {key} not found.")
        return keyValuePair[1]
        
    def __setitem__(self, key, value):
        index = self.getValidIndex(key)
        self.dataList[index] = (key, value)

    def __iter__(self):
        return (kv for kv in self.dataList if kv is not None)
    
    def __len__(self):
        return len(self.dataList)
    
    def __repr__(self):
        from textwrap import indent
        pairs = [indent(f"{repr(kv[0])} : {repr(kv[1])}", '  ') for kv in self]
        return "{\n" + ",\n".join(pairs) + "\n}"
    
    def __str__(self):
        return repr(self)

# Example Usage
HashMap = HashTable(4096)
HashMap["aakash"] = 998786
print(HashMap["aakash"])  # Output: 998786
