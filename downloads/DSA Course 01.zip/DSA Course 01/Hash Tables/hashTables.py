class HashTable:
    def __init__(self, maxHashTableSize):
        self.dataList = [None] * maxHashTableSize
        
    #Working ✅
    def getIndex(targetList, element):
        ordValue = 0
        for currntCharacter in element:
            ordValue += ord(currntCharacter)
        return ordValue % len(targetList.dataList)
    
    #working ✅
    def insert(targetList, element, value):
        targetList.dataList[HashTable.getIndex(targetList, element)] = (element, value)
        return targetList
    
    #Working ✅
    def find(targetList, element):
        index = HashTable.getIndex(targetList, element)
        return (targetList.dataList[index])
    
    #Working ✅
    def update(targetList, targetElement, newValue):
        index = HashTable.getIndex(targetList, targetElement)
        targetList.dataList[index] = (targetElement, newValue)
        return targetList
    
    #Working ✅
    def listAll(targetList):
        return [x for x in targetList.dataList if x is not None]
    
    #
    def getValidIndex():
        pass
    
maxHashTableSize = 4096
hashMap = HashTable(maxHashTableSize)
print(HashTable.getIndex(hashMap, "Aakash"))
hashMap = HashTable.insert(hashMap, "Aakash", "Aakash Rai")
hashMap = HashTable.insert(hashMap, "Binaj", "Binaj Rai")
print(HashTable.find(hashMap, "Binaj"))
print(HashTable.find(hashMap, "Aakash"))
print(HashTable.listAll(hashMap))














##############################################################################################
# Here's a simple algorithm for hashing, which can convert strings into numeric list indices.
##############################################################################################
#1. Iterate over the string, character by character
#2. Convert each character to a number using Python's built-in ord function.
#3. Add the numbers for each character to obtain the hash for the entire string
#4. Take the remainder of the result with the size of the data list
##############################################################################################



