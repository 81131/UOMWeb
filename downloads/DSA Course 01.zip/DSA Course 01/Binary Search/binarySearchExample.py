import time
original_array = list(range(100000000)) # Rotate the array by 250 positions 
rotate_by = 99999999
#           1000000
rotated_array = original_array[-rotate_by:] + original_array[:-rotate_by] # Test input 
test = { 'input': { 'nums': rotated_array }, 'output': rotate_by } 
nums0 = test['input']['nums']
def rotatedTimeCalcLinear(rotatedList):
    lo, hi = 0, len(rotatedList) - 1
    rotatedTime = 0
    while True:
        if rotatedList[lo] > rotatedList[hi]:
            rotatedTime +=1
            lo = lo+1
        else:
            return rotatedTime

def rotatedtimeCalcBinary(rotatedList):
    lo, hi = 0, len(rotatedList) -1
    mid = 0
    if rotatedList[lo] <= rotatedList[hi]: 
        return 0
    while rotatedList[lo] > rotatedList[hi]:
        mid = (lo + hi)//2
        if (rotatedList[mid] > rotatedList[hi]):
            lo = mid + 1
        elif (rotatedList[mid] < rotatedList[hi]):
            hi = mid
    return lo

print("\n\n---BINARY SERACH---")
startTime = time.time()
result = rotatedtimeCalcBinary(nums0)
endTime = time.time()
binTimeTaken = endTime - startTime
print("Took ", binTimeTaken, " to complete binary search.")
print("Rotated " , result , " times to get original array.")
print("\n\n")


print("---LINEAR  SERACH---")
startTime = time.time()
result = rotatedTimeCalcLinear(nums0)
endTime = time.time()
linTimeTaken = endTime - startTime
print("Took ", linTimeTaken, " to complete linear search.")
print("Rotated ", result , " times to get original array.")
print("\n\n")
        
print("--- CONCLUSION ---")
print("Binary search took ", binTimeTaken, " and linear search took ", linTimeTaken, ".")
print("Time difference = ", (linTimeTaken - binTimeTaken))
print("Hence, binary search is ", round(linTimeTaken / binTimeTaken), " times faster than the linear search.")
print("\n\n")


"""This program is created by a beginner developer. Might have some bugs :)"""