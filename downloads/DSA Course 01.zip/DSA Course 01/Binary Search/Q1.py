import time


cards = list(range(1000000000,0,-1))
query = 1
output = (1000000000-1)
def binarySearch(cards, query):
    lo, hi = 0, len(cards) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        if cards[mid] == query:
            return mid
        elif cards[mid] > query:
            lo = mid+1
        else:
            hi = mid -1
    return -1

def linearSearch(cards,query):
    i = 0
    while i <= len(cards) - 1:
        if cards[i] == query:
            return i
        else:
            i +=1
    return -1

print("\n\n---BINARY SERACH---")
startTime = time.time()
result = binarySearch(cards,query)
endTime = time.time()
binTimeTaken = endTime - startTime
print("Took ", binTimeTaken, " to complete binary search.")
if (result == output):
    print("Correct. Found the value ", query, " at position", result)
elif (result == -1):
    print("Not found")
else:
    print("NOT WORKING")
print("\n\n")


print("\n\n---LINEAR SERACH---")
startTime = time.time()
result = linearSearch(cards,query)
endTime = time.time()
linTimeTaken = endTime - startTime
print("Took ", linTimeTaken, " to complete linear search.")
if (result == output):
    print("Correct. Found the value ", query, " at position", result)
elif (result == -1):
    print("Not found")
else:
    print("NOT WORKING")
print("\n\n")
        
print("--- CONCLUSION ---")
print("Binary search took ", binTimeTaken, " and linear search took ", linTimeTaken, ".")
print("Time difference = ", (linTimeTaken - binTimeTaken))
print("Hence, binary search is ", round(linTimeTaken / binTimeTaken), " times faster than the linear search.")
print("\n\n")
